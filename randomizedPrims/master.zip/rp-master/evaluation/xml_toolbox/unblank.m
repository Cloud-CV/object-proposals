%
%  UNBLANK(S) removes leading and trailing blanks from string S.
%
 
 
